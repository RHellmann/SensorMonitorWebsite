                                    
$(document).ready(function test()  
{
	"use strict"; 
	 var userInput = document.getElementById("userInput").value;  
	 console.log(userInput); 
	 
	
for( var i; i <= userInput; i++)   
{
	
	  var ni = document.getElementById('sensors'); 
	
	  var newdiv = document.createElement('div'); 
	
	  var divIdName = 'myDiv' + i; 
	
	  newdiv.setAttribute('id',divIdName);
	
	  newdiv.innerHTML = ' <div> <div class="form-group"> <label>Sensor Sublink</label> <input type="text" class="form-control" placeholder="Enter ..."> </div> <div class="form-group"> <label>Select unit</label> <select class="form-control"> <option> &deg;C </option> <option> % </option> <option> Lux </option> </select> </div> </div>  ';
	
	  ni.appendChild(newdiv); 
	
	  console.log(i); 
}
	
	
	  
	
});

